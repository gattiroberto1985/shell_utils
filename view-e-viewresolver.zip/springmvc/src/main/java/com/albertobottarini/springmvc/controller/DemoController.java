package com.albertobottarini.springmvc.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

@Controller
public class DemoController {

	@RequestMapping(value="/pagina-personale", method=RequestMethod.GET)
	public String paginaPersonale(Model model) {
		model.addAttribute("nome", "Alberto");
		model.addAttribute("cognome", "Bottarini");
		return "pagina-personale";
	}
	
	@RequestMapping(value="/csv", method=RequestMethod.GET)
	public String getCSV(Model model) {
		String[] names = new String[] { "Alberto", "Luca", "Claudio" };
		model.addAttribute("names", names);
		return "CSVView";
	}

}
